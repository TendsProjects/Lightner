#ifndef MY_HEADER_H
#define MY_HEADER_H

// Объявление глобальной переменной
extern const char* version;


#endif // MY_HEADER_H
