
void print(const char* message, int row);

// В screen.cpp
void print(const char* message, int row) {
    char* video_memory = (char*)0xB8000;
    const char color = 0x07;

    for (int i = 0; message[i] != '\0'; ++i) {
        video_memory[(row * 80 + i) * 2] = message[i];      // Символ
        video_memory[(row * 80 + i) * 2 + 1] = color;      // Атрибут (цвет)
    }
}
