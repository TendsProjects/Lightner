#ifndef GDI_H
#define GDI_H

// Определение типа для цвета (ARGB)
typedef struct {
    unsigned char a; // Прозрачность
    unsigned char r; // Красный
    unsigned char g; // Зеленый
    unsigned char b; // Синий
} Color;

// Прямоугольник
typedef struct {
    int x, y, width, height;
} Rect;

// Функции работы с графикой
void set_pixel(int x, int y, Color color);
void draw_rectangle(Rect rect, Color color, int filled);
void clear_screen(Color color);

#endif
