#include "gdi.h"
/*

// Укажите размер экрана
#define SCREEN_WIDTH  800
#define SCREEN_HEIGHT 600

// Видеобуфер
volatile unsigned char* framebuffer = (unsigned char*)0xA0000; // Адрес видеопамяти в реальном режиме (VGA)

// Установить пиксель
void set_pixel(int x, int y, Color color) {
    if (x >= 0 && x < SCREEN_WIDTH && y >= 0 && y < SCREEN_HEIGHT) {
        unsigned int offset = (y * SCREEN_WIDTH + x) * 3; // Учитываем 3 байта на пиксель (R, G, B)
        framebuffer[offset] = color.r;
        framebuffer[offset + 1] = color.g;
        framebuffer[offset + 2] = color.b;
    }
}

// Нарисовать прямоугольник
void draw_rectangle(Rect rect, Color color, int filled) {
    for (int y = rect.y; y < rect.y + rect.height; y++) {
        for (int x = rect.x; x < rect.x + rect.width; x++) {
            if (filled || y == rect.y || y == rect.y + rect.height - 1 || x == rect.x || x == rect.x + rect.width - 1) {
                set_pixel(x, y, color);
            }
        }
    }
}

// Очистить экран
void clear_screen(Color color) {
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            set_pixel(x, y, color);
        }
    }
}     */
