#ifndef SCREEN_H
#define SCREEN_H

// Прототип функции
void print(const char* message, int row);

#endif // SCREEN_H
