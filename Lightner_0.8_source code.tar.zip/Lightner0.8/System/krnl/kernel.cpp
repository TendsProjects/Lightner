#include "libraries/screen.h"
#include "libraries/gui/gdi.h"
#include "SystemVariables.h"
extern "C" void main() {
    



    print("Loading...", 0);
    print("Welcome to Lightner", 1);
    print("Tends Company 2024", 25);
    print(version, 4);
    

    



    return;
}
