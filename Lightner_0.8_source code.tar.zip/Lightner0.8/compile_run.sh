#!/bin/bash

# Добавляем кросс-компилятор в PATH
export PATH=$PATH:/usr/local/i386elfgcc/bin

# Ассемблер: собираем загрузчик
nasm "System/bootmgr/boot.asm" -f bin -o "Binaries/boot.bin"

# Ассемблер: точка входа ядра
nasm "System/krnl/kernel_entry.asm" -f elf -o "Binaries/kernel_entry.o"

# Компиляция screen.cpp в объектный файл
i386-elf-gcc -ffreestanding -m32 -g -c "System/krnl/libraries/screen.cpp" -o "Binaries/screen.o"

# Компиляция kernel.cpp в объектный файл
i386-elf-gcc -ffreestanding -m32 -g -c "System/krnl/kernel.cpp" -o "Binaries/kernel.o"

# Компиляция gdt.h (в составе gdi или других файлов) в объектный файл
i386-elf-gcc -ffreestanding -m32 -g -c "System/krnl/libraries/gui/gdi.cpp" -o "Binaries/gdi.o"

# Ассемблер: создаём блок нулей
nasm "System/zeroes.asm" -f bin -o "Binaries/zeroes.bin"

# Линкуем объектные файлы ядра
i386-elf-ld -o "Binaries/full_kernel.bin" -Ttext 0x1000 \
    "Binaries/kernel_entry.o" "Binaries/screen.o" "Binaries/kernel.o" "Binaries/gdi.o" \
    --oformat binary

# Объединяем загрузчик, ядро и блок нулей в один образ
cat "Binaries/boot.bin" "Binaries/full_kernel.bin" "Binaries/zeroes.bin" > "Binaries/OS.bin"

# Запускаем образ в QEMU
qemu-system-x86_64 -drive format=raw,file="Binaries/OS.bin",index=0,if=floppy, -m 128M
